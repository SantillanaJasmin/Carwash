package com.example.jasmin.carwash;

/**
 * Created by Jasmin on 1/16/2017.
 */
public class History {

    public static final String TABLE_NAME = "history";
    public static final String COLUMN_ID = "_id";   //primary key
    public static final String COLUMN_TRANS_NUMBER = "trans_number";
    public static final String COLUMN_TRANS_PRICE= "trans_price";
    public static final String COLUMN_TRANS_DETAILS = "trans_details";

    private int id;
    private double trans_price;
    private String trans_number, trans_details;

    public History() {

    }

    public String getTrans_number() {
        return trans_number;
    }

    public void setTrans_number(String trans_number) {
        this.trans_number = trans_number;
    }

    public double getPrice() {
        return trans_price;
    }

    public void setPrice(double price) {
        this.trans_price = price;
    }

    public String getDetails() {
        return trans_details;
    }

    public void setDetails(String details) {
        this.trans_details = details;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
