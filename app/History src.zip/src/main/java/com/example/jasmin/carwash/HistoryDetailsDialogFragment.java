package com.example.jasmin.carwash;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

/**
 * Created by Jasmin on 1/23/2017.
 */
public class HistoryDetailsDialogFragment extends DialogFragment {
    View v;

    public static HistoryDetailsDialogFragment newInstance(int id) {
        HistoryDetailsDialogFragment f = new HistoryDetailsDialogFragment();

        // Supply num input as an argument.
        Bundle args = new Bundle();
        args.putInt("id", id);
        f.setArguments(args);

        return f;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
//        v = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_history_details, null);

        final int dbid = getArguments().getInt("id");
        final HistoryDBOpenHelper dbHistory = new HistoryDBOpenHelper(getActivity());
        History historyItem = dbHistory.getHistory(dbid);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity())
                .setTitle("Transaction Details")
                .setMessage("Number: " + historyItem.getTrans_number() + "\n\nPrice: " + historyItem.getPrice() + "\n\nDescription: " + historyItem.getDetails())
                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dismiss();  //if the user clicks on yes, exit dialog
                    }
                });

        return dialogBuilder.create();
    }
}
