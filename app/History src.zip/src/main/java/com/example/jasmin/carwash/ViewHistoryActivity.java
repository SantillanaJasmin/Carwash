package com.example.jasmin.carwash;

import android.app.DialogFragment;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ViewHistoryActivity extends AppCompatActivity {

    ArrayList<History> historyArray;
    HistoryCursorAdapter historyCursorAdapter;
    HistoryDBOpenHelper dbHistory;
    RecyclerView rvHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_history);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        historyArray = new ArrayList<>();

        rvHistory = (RecyclerView) findViewById(R.id.rvHistory);

        dbHistory = new HistoryDBOpenHelper(getBaseContext());
        dbHistory.addHistory();

        Cursor cursor = dbHistory.getAllHistory();

        historyCursorAdapter = new HistoryCursorAdapter(getBaseContext(), cursor);
        rvHistory.setAdapter(historyCursorAdapter);
        rvHistory.setLayoutManager(new LinearLayoutManager(getBaseContext()));

        historyCursorAdapter.setmOnDetailClickListener(new HistoryCursorAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int id) {
                DialogFragment detailsDialogFragment = HistoryDetailsDialogFragment.newInstance(id);
                detailsDialogFragment.show(getFragmentManager(), "DETAILS");
            }
        });

        historyCursorAdapter.setmOnDeleteClickListener(new HistoryCursorAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int id) {
                DialogFragment deleteDialogFragment = DeleteHistoryDialogFragment.newInstance(id);
                deleteDialogFragment.show(getFragmentManager(), "DELETE");
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Cursor cursor = dbHistory.getAllHistory();
        historyCursorAdapter.swapCursor(cursor); //gives new cursor
    }

    public void onFinishDialog() {
        historyCursorAdapter.notifyDataSetChanged();
        Toast.makeText(getBaseContext(), "Deleted", Toast.LENGTH_SHORT).show();
    }

    public class HistoryAsyncTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String url = "<url>";

            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(url)
                            //.post(requestBody)
                    .build();

            Response response;
            try {
                response = client.newCall(request).execute();
                return response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            ArrayList<History> historyList = new ArrayList<History>();

            try {
                JSONArray historyArray = new JSONArray(s);

                for(int i = 0; i < historyArray.length(); i++) {
                    JSONObject history = historyArray.getJSONObject(i);
//                    int id = student.getInt("id");
//                    String name = student.getString("name");
//                    students.add(new Student(id, name));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
//            tvResult.setText(s);
        }
    }
}
