package com.example.jasmin.carwash;

import android.content.Context;
import android.database.Cursor;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Jasmin on 1/23/2017.
 */
public class HistoryCursorAdapter extends CursorRecyclerViewAdapter<HistoryCursorAdapter.HistoryViewHolder> {

    private Context appContext;
    private OnItemClickListener mOnDetailClickListener, mOnDeleteClickListener;

    public void setmOnDetailClickListener(OnItemClickListener m) {
        this.mOnDetailClickListener = m;
    }

    public void setmOnDeleteClickListener(OnItemClickListener m) {
        this.mOnDeleteClickListener = m;
    }

    public HistoryCursorAdapter(Context context, Cursor cursor) {
        super(context, cursor);

        this.appContext = context;
    }

    @Override
    public void onBindViewHolder(final HistoryViewHolder viewHolder, Cursor cursor) {
        final String trans_id = String.valueOf(cursor.getInt(cursor.getColumnIndex(History.COLUMN_ID)));
        final String trans_number = cursor.getString(cursor.getColumnIndex(History.COLUMN_TRANS_NUMBER));
        final String trans_price = String.valueOf(cursor.getDouble(cursor.getColumnIndex(History.COLUMN_TRANS_PRICE)));

        viewHolder.tvTransNumberField.setText(trans_number + " (" + trans_id + ")");
        viewHolder.tvTransPriceField.setText(trans_price);

        viewHolder.tvOverflow.setTag(cursor.getInt(cursor.getColumnIndex(History.COLUMN_ID)));
        viewHolder.tvOverflow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int dbid = Integer.parseInt(v.getTag().toString());
                PopupMenu popup = new PopupMenu(v.getContext(), viewHolder.tvOverflow);
                MenuInflater inflater = popup.getMenuInflater();
                inflater.inflate(R.menu.popup_menu, popup.getMenu());
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.item_details:
                                //handle menu1 click
                                mOnDetailClickListener.onItemClick(dbid);
                                break;
                            case R.id.item_delete:
                                //handle menu2 click
                                mOnDeleteClickListener.onItemClick(dbid);
                                break;
                            default:
                        }
                        return false;
                    }
                });
                popup.show();
            }
        });
    }

    public interface OnItemClickListener {
        public void onItemClick(int id);
    }

    @Override
    public HistoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.history_item, parent, false);
        return new HistoryViewHolder(v);
    }

    public class HistoryViewHolder extends RecyclerView.ViewHolder {

        TextView tvOverflow, tvTransNumberLabel, tvTransNumberField, tvTransPriceLabel, tvTransPriceField;
        View container;

        public HistoryViewHolder(View itemView) {
            super(itemView);

            tvOverflow = (TextView) itemView.findViewById(R.id.tvOverflow);
            tvTransNumberLabel = (TextView) itemView.findViewById(R.id.tvTransNumberLabel);
            tvTransNumberField = (TextView) itemView.findViewById(R.id.tvTransNumberField);
            tvTransPriceLabel = (TextView) itemView.findViewById(R.id.tvTransPriceLabel);
            tvTransPriceField = (TextView) itemView.findViewById(R.id.tvTransPriceField);

            container = itemView.findViewById(R.id.container);
        }
    }
}
