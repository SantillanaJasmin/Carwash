package com.example.jasmin.carwash;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

/**
 * Created by Jasmin on 1/25/2017.
 */
public class DeleteHistoryDialogFragment extends DialogFragment {

    View v;

    public static DeleteHistoryDialogFragment newInstance(int id) {
        DeleteHistoryDialogFragment f = new DeleteHistoryDialogFragment();

        // Supply num input as an argument.
        Bundle args = new Bundle();
        args.putInt("id", id);
        f.setArguments(args);

        return f;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        //        v = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_history_details, null);

        final int dbid = getArguments().getInt("id");
        final HistoryDBOpenHelper dbHistory = new HistoryDBOpenHelper(getActivity());
        final History historyItem = dbHistory.getHistory(dbid);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity())
                .setTitle("Are your sure you want to delete this?")
                .setMessage("ID: " + historyItem.getId() + "\n\nNumber: " + historyItem.getTrans_number() + "\n\nPrice: " + historyItem.getPrice() + "\n\nDescription: " + historyItem.getDetails())
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int num = dbHistory.deleteHistory(historyItem);
                        getDialog().dismiss();
                        ViewHistoryActivity activity = (ViewHistoryActivity) getActivity();
                        activity.onFinishDialog();;
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dismiss();
                    }
                });

        return dialogBuilder.create();
    }
}
