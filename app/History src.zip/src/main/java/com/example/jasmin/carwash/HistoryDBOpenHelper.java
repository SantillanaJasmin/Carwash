package com.example.jasmin.carwash;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Jasmin on 1/18/2017.
 */
public class HistoryDBOpenHelper extends SQLiteOpenHelper {

    private static String DB_PATH = "";
    public static final String DB_SCHEMA = "carwash";

    public HistoryDBOpenHelper(Context context) {
        super(context, DB_SCHEMA, null, 1);

    }

    // Creates a empty database on the system and rewrites it with your own database.
    // public void create() throws IOException {
    //     boolean dbExist = checkDataBase();
 
    //     if (dbExist) {
    //         //do nothing - database already exist
    //     } else {
    //         // By calling this method and empty database will be created into the default system path
    //         // of your application so we are gonna be able to overwrite that database with our database.
    //         this.getReadableDatabase();
    //         try {
    //             copyDataBase();
    //         } catch (IOException e) {
    //             throw new Error("Error copying database");
    //         }
    //     }
    // }
 
    // // Check if the database exist to avoid re-copy the data
    // private boolean checkDataBase() {
    //     SQLiteDatabase checkDB = null;
    //     try {
    //         String path = DB_PATH + DB_SCHEMA;
    //         checkDB = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY);
    //     } catch (SQLiteException e) {
    //         // database don't exist yet.
    //         e.printStackTrace();
    //     }
    //     if (checkDB != null) {
    //         checkDB.close();
    //     }
    //     return checkDB != null ? true : false;
    // }
 
    // // copy your assets db
    // private void copyDataBase() throws IOException {
    //     //Open your local db as the input stream
    //     InputStream myInput = context.getAssets().open(DB_SCHEMA);
 
    //     String outFileName = DB_PATH + DB_SCHEMA;
 
    //     //Open the empty db as the output stream
    //     OutputStream myOutput = new FileOutputStream(outFileName);
 
    //     //transfer bytes from the inputfile to the outputfile
    //     byte[] buffer = new byte[1024];
    //     int length;
    //     while ((length = myInput.read(buffer)) > 0) {
    //         myOutput.write(buffer, 0, length);
    //     }
 
    //     myOutput.flush();
    //     myOutput.close();
    //     myInput.close();
    // }
 
    // //Open the database
    // public boolean open() {
    //     try {
    //         String myPath = DB_PATH + DB_SCHEMA;
    //         db = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);
    //         return true;
    //     } catch (SQLException sqle) {
    //         db = null;
    //         return false;
    //     }
    // }
 
    // @Override
    // public synchronized void close() {
    //     if (db != null)
    //         db.close();
    //     super.close();
    // }

    @Override
    public void onCreate(SQLiteDatabase db) {
//        CREATE TABLE `History` (
//        `trans_number`	TEXT,
//        `trans_price`	REAL,
//        `trans_details`	TEXT,
//                PRIMARY KEY(`trans_number`)
//        ) WITHOUT ROWID;
        String sql_query = "CREATE TABLE " + History.TABLE_NAME + " ( "
                + History.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + History.COLUMN_TRANS_NUMBER + " TEXT,"
                + History.COLUMN_TRANS_PRICE + " REAL,"
                + History.COLUMN_TRANS_DETAILS + " TEXT);";
        db.execSQL(sql_query);
    }

    public void addHistory() {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(History.COLUMN_TRANS_NUMBER, "2198abcd");
        cv.put(History.COLUMN_TRANS_PRICE, 750.00);
        cv.put(History.COLUMN_TRANS_DETAILS, "huwaw huwaw huwaw huwaw");

        db.insert(History.TABLE_NAME, null, cv);
        db.close();
    }

    public History getHistory(int id) {
        History history = new History();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(History.TABLE_NAME,
                null,
                " " + History.COLUMN_ID + " =? ",
                new String[]{String.valueOf(id)},
                null, null, null);
        if(c.moveToFirst()) {
            history.setId(id);
            history.setTrans_number(c.getString(c.getColumnIndex(History.COLUMN_TRANS_NUMBER)));
            history.setPrice(c.getDouble(c.getColumnIndex(History.COLUMN_TRANS_PRICE)));
            history.setDetails(c.getString(c.getColumnIndex(History.COLUMN_TRANS_DETAILS)));
        } else {
            history = null;
        }

        c.close();
        db.close();
        return history;
    }

    public Cursor getAllHistory() {
        //ArrayList<Note> notes = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(History.TABLE_NAME, null, null, null, null, null, null);
        return c;
    }

    public int deleteHistory(History history) {
        SQLiteDatabase db = getWritableDatabase();
        int num = db.delete(History.TABLE_NAME, " " + History.COLUMN_ID + " =? ", new String[]{String.valueOf(history.getId())});


        return num;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
